# QBER Model Module Review

This document reviews the proposed `qber_model.py` module for QBER prediction and provides suggestions for safe next steps.

## Observations

- The module defines a compact MLP (128/64/32 hidden units with ReLU) for regression and optimizes with Adam and MSE, reporting MAE for readability.
- Data ingestion is CSV-based with configurable feature and target columns and minimal preprocessing beyond `dropna`.
- Training uses shuffled `tf.data` pipelines, early stopping, and best-checkpoint saving to `model.keras` in a configurable artifacts directory.
- Prediction helpers cover batch inference and a simple mu-suggestion policy that nudges mean-photon-number based on the predicted QBER relative to a ceiling.

## Suggestions and Next Steps

1. **Data quality and preprocessing**
   - Add basic schema validation (required columns, dtypes, range checks) before training to catch telemetry anomalies.
   - Consider feature scaling/normalization (e.g., `tf.keras.layers.Normalization` or `sklearn` preprocessing) to help optimizer stability across heterogeneous telemetry ranges.
   - Track dataset statistics (mean/std, min/max) alongside the saved model so inference uses the same transformations.

2. **Model architecture and training improvements**
   - Introduce regularization (dropout or L2) and tune hidden layer widths/depths with a small hyperparameter sweep to balance bias/variance.
   - Use a learning-rate scheduler (e.g., cosine decay or ReduceLROnPlateau) to tighten convergence after plateauing.
   - Log training history (loss/MAE) to a lightweight artifact (CSV/JSON) to support later analysis and regression testing.

3. **Evaluation and monitoring**
   - Reserve a test split and compute domain-relevant metrics (RMSE/MAE and calibration plots of predicted vs. measured QBER).
   - Add simple drift detection by periodically evaluating the latest telemetry against the validation/test sets and alerting on degraded metrics.

4. **mu suggestion policy hardening**
   - Bound input telemetry and `current_mu` to physical/operational limits before inference; surface warnings when inputs are out of range.
   - Consider a small grid or gradient-free search around the current mu using the model to pick the best step that satisfies the QBER ceiling with margin.
   - Log the predicted QBER, chosen mu, and rationale to support auditability and offline tuning of the policy thresholds.

5. **Reproducibility and packaging**
   - Persist the training configuration (feature list, hyperparameters, seed) with the saved model to guarantee repeatable runs.
   - Add a CLI entry point (e.g., `python -m bridge.ml.qber_model train --config configs/qber.yaml`) and document expected telemetry schema in the repository docs.
   - Include lightweight unit tests for dataset creation, prediction shapes, and mu-suggestion behavior using synthetic data; gate them behind a "no-TF" skip marker if GPU/TF is unavailable in CI.
