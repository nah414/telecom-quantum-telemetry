"""QCS dual-clock daemon entrypoint package."""

__all__ = []
